module.exports = {
  removals: [/FeatureToggles\..*/],
  additions: [/FeatureToggles\..*/],
  changes: [/FeatureToggles\..*/],
};
