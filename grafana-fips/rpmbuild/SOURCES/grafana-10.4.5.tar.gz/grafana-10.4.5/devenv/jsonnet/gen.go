package jsonnet

//go:generate go run dev-dashboards.go
