---
name: Chore
about: Create an issue for a chore needing completion
labels: 'type: chore'
---

<!--
Please use this template to create your chore issue. You can use this template if you spot an out-of-date README, discover a misspelling, or happen upon a deeply nested 7-layer for-loop that could be better handled another way. Please use this template for your non-bug related fixes/updates/refactors.

- Questions should be posted to: https://community.grafana.com
- Use query inspector to troubleshoot issues: https://bit.ly/2XNF6YS
- How to record and attach gif: https://bit.ly/2Mi8T6K
-->

**What is the chore?**:

**Is there anything else we need to know?**:
