This devenv docker-compose.yaml will allow you to;
- search traces
- view traces
- upload/download trace JSON files
- view service graphs
- search traces via Loki
